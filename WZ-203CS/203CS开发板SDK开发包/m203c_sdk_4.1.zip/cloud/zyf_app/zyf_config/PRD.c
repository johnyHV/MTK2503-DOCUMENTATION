#include "PRD.h"
#include "pro.h"
/*
0871:联网时间,

08E3:GPS定位时间,

1E9D:电量百分比,

023A:信号强度,

2557:运行时长,

01EC:加速度x-y-z,

1792:LBS(纬度),

087B:LBS(经度),

1480:GPS(纬度),

00EA:GPS(经度）,

2160:充电状态,

0726:电压,

66AA:LED灯,

22BC:传输间隔
*/
tlv AutomaticRDTlv[READONLYNUM]={{0x0871,0x0a,{0}},{0x08E3,0x0a,{0}},{0x1E9D,0x04,{0}},{0x023A,0x03,{0}},{0x2557,0x0a,{0}},{0x01EC,0x0f,{0}},{0x1792,0x0c,{0}},{0x087B,0x0c,{0}},{0x1480,0x0c,{0}},{0x00EA,0x0c,{0}},{0x2160,0x02,{0}},{0x0726,0x06,{0}}};
tlv AutomaticWRTlv[READWRITE]={{0x66AA,0x01,{0}},{0x22BC,0x0a,{0}}};