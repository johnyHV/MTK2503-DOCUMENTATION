
#include "ql_type.h"
#include "ql_trace.h"
#include "ql_uart.h"
#include "ql_system.h"
#include "ql_stdlib.h"
#include "ql_error.h"
#include "ql_gpio.h"
#include "ql_iic.h"
#include "uart.h"
#include "sys.h"
#include "ads1151.h"


//unsigned char ReadBuffer[2];
/*******************************************************************************
* Function Name  : ads1151_i2c_init
* 参数           : 初始化i2c
* Attention  写i2c数据
*******************************************************************************/
int ads1151_i2c_init(void)
{
	s32 ret;
	ret = Ql_IIC_Init(1,PINNAME_RI,PINNAME_DCD,0);
	if(ret < 0)
	{
	//	mprintf("\r\n<--Failed!! IIC controller Ql_IIC_Init channel 1 fail ret=%d-->\r\n",ret);
		return ret;	
	}
	mprintf("\r\n<--pins(SCL=%d,SDA=%d) IIC controller Ql_IIC_Init channel 1 ret=%d-->\r\n",PINNAME_RI,PINNAME_DCD,ret);
	ret = Ql_IIC_Config(1,TRUE, 0x90, 300);
	if(ret < 0)
	{
	//	mprintf("\r\n<--Failed !! IIC controller Ql_IIC_Config channel 1 fail ret=%d-->\r\n",ret);
		return ret;
	}		
	//mprintf("\r\n<--IIC controller Ql_IIC_Config channel 1 ret=%d-->\r\n",ret);
	return ret;
}
/*******************************************************************************
* Function Name  : ads_i2c_read
* 参数       
                   addr：寄存器地址
				   *data 存储读出的数据
				 
* Attention  读i2c数据
*******************************************************************************/
 int ads_i2c_read(u8 addr, u8 *data)
{
	int res = 0;
	res=Ql_IIC_Write(ADS1151_CHNUM,0x90,&addr,0x01);
	if(res< 0)
	{
	//	mprintf("\r\n<--Failed !! IIC controller Ql_IIC_Write channel 1 fail ret=%d-->\r\n",res);
		return res;	
	}
	res = Ql_IIC_Read(ADS1151_CHNUM, 0x90, data, 0x02);
	
	if(res < 0)
	{
	//	mprintf("\r\n<--Failed !! IIC controller Ql_IIC_Read channel 1 fail ret=%d-->\r\n",res);
		return data;	
	}
	return data;
}
/*******************************************************************************
* Function Name  : ads_i2c_write
* 参数       
                   addr：寄存器地址
				   *data 存储读出的数据
				 
* Attention  读i2c数据
*******************************************************************************/
int ads_i2c_write(u8 addr, u8 *data)
{
     u8 buf[3]={0,0,0};
	 buf[0]=addr;
	 buf[1]=data[0];
	 buf[2]=data[1];
	int res = 0;
	res=Ql_IIC_Write(ADS1151_CHNUM,0x90,buf,0x03);
		if(res< 0)
	{
	//	mprintf("\r\n<--Failed !! IIC controller Ql_IIC_Write channel 1 fail ret=%d-->\r\n",res);
		return res;	
	}
		return res;
	
}


/*******************************************************************************
* Function Name  : Confige1115
* 参数           : 通道0/1/2/3
* Attention :配置ADS1115，根据需要的通道进行配置
*******************************************************************************/

static void Confige1115 (unsigned char port)
{
    static unsigned char chnel, i;
	u8 databuf[2]={0,0}; 

	u8 buf_read[ADS1151_DATA_LEN] = {0};

	 int res = 0;
	 u8 mpuid;
    switch (port)
    {
      case 0:               //0通道
          chnel=0xC2; 
      break;
      
      case 1:               //1通道  
          chnel=0xD2;
      break;
          
      case 2:               //2通道  
          chnel=0xE2;
      break;
          
      case 3:               //3通道
          chnel=0xF2;
      break;
          
      default:
      break; 
    }   
	databuf[0]=chnel;
	databuf[1]=0x83;

	res = ads_i2c_write(CMD_CONF_REG,databuf);//写入数据
	ads_i2c_read(0x01, buf_read);
	if(res < 0)
	{
		return ADS1151_ERR_I2C;
	}
  
       
}

/*******************************************************************************
* 读取ADS1115的16位数据
*******************************************************************************/
static u16 ReadData (unsigned char chnnal1)
{
    unsigned char ReadBuffer[2]={0,0};
	u16  data=0;
	int res = 0;
	u8 buf[ADS1151_DATA_LEN] = {0};
	ads_i2c_read(0x00, buf);////读取数据
    Delayus(200);
	ReadBuffer[0]=buf[0];
	ReadBuffer[1]=buf[1];
	Delayus(200);
  	data = ReadBuffer[0]*256+ReadBuffer[1];  ////数据处理
	return data;
}


/*******************************************************************************
* Function Name  : Get_ATOD
* Attention :获取ADS1115模拟转换结果
*******************************************************************************/
float Get_ATOD (unsigned char channel)
{
	static unsigned char chn; 
	u16 data_get;
	chn = channel; 
	float vol; 
	Confige1115(channel); ////配置ADS1115转换通道
	data_get = ReadData(chn);  ////从通道中读数据
	/**用于测量负电压，负电压从8000~ffff,负电压与正关于0有类似对称关系，按位取反后+1相同**/
	if(data_get>=0x8000)  
		vol=((float)(0xffff-data_get)/32768.0)*4.096;
	else
		vol=((float)data_get/32768.0)*4.096;
	vol=vol*1000;
				return vol;
}

