
extern u32 NetworkTime,GpsPositioningTime;